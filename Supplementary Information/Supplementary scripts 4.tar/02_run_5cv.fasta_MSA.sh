#!/bin/sh
# zagor

# see https://www.cyberciti.biz/howto/question/general/compress-file-unix-linux-cheat-sheet.php in the case you need to uncompress some data


# scripts, at this moment, need to be in directory where we have fastas and paralogue clusters files containing gene IDs
mv print.sh ../output/
mv MSA.py ../output/
cd ../output/
chmod 755 MSA.py
chmod 755 print.sh


cp ../../_A_02_components_1_3cvs-gffmerged/output/stPanTr_aa_alternatives.fasta .
cp ../../_A_02_components_1_3cvs-gffmerged/output/stPanTr_aa_representatives.fasta .
cp ../../../_S_03_stCuSTr/_A_03.2_components/output/fasta_1B_alt-per-cv/stCuSTr-D_aa_alternatives.fasta .
cp ../../../_S_03_stCuSTr/_A_03.2_components/output/fasta_1B_alt-per-cv/stCuSTr-P_aa_alternatives.fasta .
cp ../../../_S_03_stCuSTr/_A_03.2_components/output/fasta_1B_alt-per-cv/stCuSTr-R_aa_alternatives.fasta .

cat *.fasta > 5cv.aa.fasta
rm stCuSTr*.fasta
rm stPanTr*.fasta

# default python is python2
python MSA.py

########################################
##        Example on test data        ##
########################################
# mv print.sh ../other/testSet/
# mv MSA.py ../other/testSet/
# cd ../other/testSet/
# chmod 755 MSA.py
# chmod 755 print.sh
# $ python2 MSA.py
#
# #####################
# ## standard output ##
# #####################
# ###    choices    ###
# #####################
#
# Hello!
#
# Did you generate the input data files?
#
# 1. Yes
# 2. No
# 3. I do not know
#
# Enter your choice [1-3] : 1
#
#
# Path to your reference .fasta file: my.fasta
# Path to your folder containing files with written gene IDs of interest, line by line: folderWithIds
# Where would you like to store your results (directory name, e.g. here/and/there)?: tstOut
# Preferred width of the alignment is (full or integer): 210
# Consensus on or off: off
# ---------------
# Choose aligner:
# 1. ClustalOmega
# 2. Muscle
# 3. MAFFT
# ---------------
# Enter your choice [1-3] : 3
# Number of iterations: 20
# Number of CPU (up to 30): 28
#
#
# #####################
# ## standard output ##
# #####################
# ## run information ##
# ##    shortened... ##
# #####################
#
# IDs1
# my.fasta
# folderWithIds/
# my.fasta
# dos2unix: converting file folderWithIds/IDs1 to Unix format ...
# mkdir: created directory 'tstOut_MAFFT_folderWithIds_210_off_20_28/'
#
# ####  ####  ####  ####  ####  ####  ####  ####  ####  ####  ####  ####
# Using: IDs1 and my.fasta
#
# get sequences
#
# MAFFT
#
# nseq =  4
# distance =  ktuples
# iterate =  16
# ...
#
# Making a distance matrix ..
# ...
# done.
#
# Constructing a UPGMA tree ...
# ...
# done.
#
# Progressive alignment 1/2...
# ...
# done.
#
# Making a distance matrix from msa..
# ...
# done.
#
# Constructing a UPGMA tree ...
# ...
# done.
#
# Progressive alignment 2/2...
# ...
# done.
#
# disttbfast (aa) Version 7.271 alg=A, model=BLOSUM62, 1.53, -0.00, -0.00, noshift, amax=0.0
# 28 thread(s)
# ...
#
#
# Strategy:
 # FFT-NS-i (Accurate but slow)
 # Iterative refinement method (max. 16 iterations)
# ...
#
#
# mview
#
# tree
#
#
 # CLUSTAL 2.1 Multiple Sequence Alignments
#
#
# Sequence format is Pearson
# ...
#
# Phylogenetic tree file created:   [./tstOut_MAFFT_folderWithIds_210_off_20_28/IDs1.ph]
#
# Results at ./tstOut_MAFFT_folderWithIds_210_off_20_28
#
# IDs2
# my.fasta
# folderWithIds/
# my.fasta
# dos2unix: converting file folderWithIds/IDs2 to Unix format ...
#
# ####  ####  ####  ####  ####  ####  ####  ####  ####  ####  ####  ####
# Using: IDs2 and my.fasta
#
# get sequences
#
# MAFFT
#
# ...
#
# mview
#
# tree
#
#
# CLUSTAL 2.1 Multiple Sequence Alignments
# ...
#
# Phylogenetic tree file created:   [./tstOut_MAFFT_folderWithIds_210_off_20_28/IDs2.ph]
#
# Results at ./tstOut_MAFFT_folderWithIds_210_off_20_28
#
#
# Finito :)
#
# mv print.sh ../../scripts/
# mv MSA.py ../../scripts/
# cd ../../scripts
#



mv print.sh ../scripts/
mv MSA.py ../scripts/
cd ../scripts

# all of size 0
rm ../output/out_MAFFT_D_P_R_g_full_off_20_28/*_.err.txt
find ../output/out_MAFFT_D_P_R_g_full_off_20_28/ -type f | sed -rn 's|.*/[^/]+\.([^/.]+)$|\1|p' | sort -u

mkdir ../output/out_MAFFT_D_P_R_g_full_off_20_28/aligned
mkdir ../output/out_MAFFT_D_P_R_g_full_off_20_28/fasta
mkdir ../output/out_MAFFT_D_P_R_g_full_off_20_28/html
mkdir ../output/out_MAFFT_D_P_R_g_full_off_20_28/ph
mkdir ../output/out_MAFFT_D_P_R_g_full_off_20_28/log

mv ../output/out_MAFFT_D_P_R_g_full_off_20_28/*aligned ../output/out_MAFFT_D_P_R_g_full_off_20_28/aligned/
mv ../output/out_MAFFT_D_P_R_g_full_off_20_28/*fasta ../output/out_MAFFT_D_P_R_g_full_off_20_28/fasta/
mv ../output/out_MAFFT_D_P_R_g_full_off_20_28/*html ../output/out_MAFFT_D_P_R_g_full_off_20_28/html/
mv ../output/out_MAFFT_D_P_R_g_full_off_20_28/*ph ../output/out_MAFFT_D_P_R_g_full_off_20_28/ph/
mv ../output/out_MAFFT_D_P_R_g_full_off_20_28/*txt ../output/out_MAFFT_D_P_R_g_full_off_20_28/log/

ll ../output/out_MAFFT_D_P_R_g_full_off_20_28/aligned/ | wc -l
ll ../output/out_MAFFT_D_P_R_g_full_off_20_28/fasta/ | wc -l
ll ../output/out_MAFFT_D_P_R_g_full_off_20_28/html/ | wc -l
ll ../output/out_MAFFT_D_P_R_g_full_off_20_28/ph/ | wc -l
ll ../output/out_MAFFT_D_P_R_g_full_off_20_28/log/ | wc -l


# merge .htmls
grep -n "TABLE"  ../output/out_MAFFT_D_P_R_g_full_off_20_28/html/stPanTr_082768.txt.aligned.mview.html
# 259:<TABLE style="border:0px;">
# 279:</TABLE>
x=$(grep -n "<TABLE " ../output/out_MAFFT_D_P_R_g_full_off_20_28/html/stPanTr_082768.txt.aligned.mview.html)
x=$(echo $x | cut -f1 -d ":")
y=$(grep -n "</TABLE>" ../output/out_MAFFT_D_P_R_g_full_off_20_28/html/stPanTr_082768.txt.aligned.mview.html)
y=$(echo $y | cut -f1 -d ":")




head -n$(expr $x - 1) ../output/out_MAFFT_D_P_R_g_full_off_20_28/html/stPanTr_082768.txt.aligned.mview.html > ../output/out_MAFFT_D_P_R_g_full_off_20_28/Merged.aa.html

for f in ../output/out_MAFFT_D_P_R_g_full_off_20_28/html/*.html
do
    sed -n "$x,$(expr $y + 1) p " $f | sed "$ d" >> ../output/out_MAFFT_D_P_R_g_full_off_20_28/Merged.aa.html
done

tail -3 ../output/out_MAFFT_D_P_R_g_full_off_20_28/html/stPanTr_082768.txt.aligned.mview.html  >> ../output/out_MAFFT_D_P_R_g_full_off_20_28/Merged.aa.html



mv print.sh ../output/
mv MSA.py ../output/
cd ../output
chmod 755 MSA.py
chmod 755 print.sh


cp ../../_A_02_components_1_3cvs-gffmerged/output/stPanTr_cds_alternatives.fasta .
cp ../../_A_02_components_1_3cvs-gffmerged/output/stPanTr_cds_representatives.fasta .
cp ../../../_S_03_stCuSTr/_A_03.2_components/output/fasta_1B_alt-per-cv/stCuSTr-D_cds_alternatives.fasta .
cp ../../../_S_03_stCuSTr/_A_03.2_components/output/fasta_1B_alt-per-cv/stCuSTr-P_cds_alternatives.fasta .
cp ../../../_S_03_stCuSTr/_A_03.2_components/output/fasta_1B_alt-per-cv/stCuSTr-R_cds_alternatives.fasta .


cat *_cds_*.fasta > 5cv.cds.fasta
rm stCuSTr*.fasta
rm stPanTr*.fasta

python MSA.py




mv print.sh ../scripts/
mv MSA.py ../scripts/
cd ../scripts


tar -zcvf ../output/D_P_R_g.tar.gz ../output/D_P_R_g/
rm -rf ../output/D_P_R_g/
mv ../output/D_P_R_g.tar.gz ../input/D_P_R_g.tar.gz

tar -zcvf ../output/selected_4_wc.tar.gz ../output/selected_4_wc/
rm -rf ../output/selected_4_wc/
mv ../output/selected_4_wc.tar.gz ../input/selected_4_wc.tar.gz

rm ../output/*.fasta
rm ../output/*.fai
