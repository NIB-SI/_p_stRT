# ZR archiving

mkdir ../intermediate

tar -zcvf ../intermediate/intermediate-1-Desiree.tar.gz ../output/intermediate/Desiree/
tar -zcvf ../intermediate/intermediate-1-PW363.tar.gz ../output/intermediate/PW363/
tar -zcvf ../intermediate/intermediate-1-Rywal.tar.gz ../output/intermediate/Rywal/

tar -zcvf ../intermediate/intermediate-2-validate-removal.tar.gz ../output/x_validate_removal/

tar -zcvf ../output/other/output_summary.tar.gz ../output/summary

mkdir ../output/other
mkdir ../output/other/output_full
mkdir ../output/other/output_full

# etc