#!/bin/sh
# zagor

# see https://www.cyberciti.biz/howto/question/general/compress-file-unix-linux-cheat-sheet.php in the case you need to uncompress some data


mkdir ../output/x_validate_removal/

cat ../output/Desiree/*drop_IDs* | sort > ../output/x_validate_removal/Desiree.removed.IDs
cat ../output/PW363/*drop_IDs* | sort > ../output/x_validate_removal/PW363.removed.IDs
cat ../output/Rywal/*drop_IDs* | sort > ../output/x_validate_removal/Rywal.removed.IDs

# tr -d '\r'
# sed -i -e 's/\r$//g' ../output/x_validate_removal/Desiree.removed.IDs;
# sed -i -e 's/\r$//g' ../output/x_validate_removal/PW363.removed.IDs;
# sed -i -e 's/\r$//g' ../output/x_validate_removal/Rywal.removed.IDs;
dos2unix ../output/x_validate_removal/Desiree.removed.IDs;
dos2unix ../output/x_validate_removal/PW363.removed.IDs;
dos2unix ../output/x_validate_removal/Rywal.removed.IDs;

cat ../../_A_01_evigene/output/Desiree.aa.fasta | cut -d ' ' -f1 > ../output/x_validate_removal/tmp;
xargs faidx -d ' ' ../output/x_validate_removal/tmp < ../output/x_validate_removal/Desiree.removed.IDs > ../output/x_validate_removal/Desiree_removed_aa 2> ../output/x_validate_removal/Desiree_removed_aa.err.txt;
rm ../output/x_validate_removal/tmp*;
fasta_formatter -i ../output/x_validate_removal/Desiree_removed_aa -o ../output/x_validate_removal/Desiree.removed.aa -w 0;
rm ../output/x_validate_removal/Desiree_removed_aa;

cat ../../_A_01_evigene/output/PW363.aa.fasta | cut -d ' ' -f1 > ../output/x_validate_removal/tmp;
xargs faidx -d ' ' ../output/x_validate_removal/tmp < ../output/x_validate_removal/PW363.removed.IDs > ../output/x_validate_removal/PW363_removed_aa 2> ../output/x_validate_removal/PW363_removed_aa.err.txt;
rm ../output/x_validate_removal/tmp*;
fasta_formatter -i ../output/x_validate_removal/PW363_removed_aa -o ../output/x_validate_removal/PW363.removed.aa -w 0;
rm ../output/x_validate_removal/PW363_removed_aa;

cat ../../_A_01_evigene/output/Rywal.aa.fasta  | cut -d ' ' -f1 > ../output/x_validate_removal/tmp;
xargs faidx -d ' ' ../output/x_validate_removal/tmp < ../output/x_validate_removal/Rywal.removed.IDs > ../output/x_validate_removal/Rywal_removed_aa 2> ../output/x_validate_removal/Rywal_removed_aa.err.txt;
rm ../output/x_validate_removal/tmp*;
fasta_formatter -i ../output/x_validate_removal/Rywal_removed_aa -o ../output/x_validate_removal/Rywal.removed.aa -w 0;
rm ../output/x_validate_removal/Rywal_removed_aa;


myBUSCO=/home/administrator/Software/busco/scripts/run_BUSCO.py
myDB=/DATA/majaz/buscoDB
# Please do not provide a full path in --out parameter, no slash. Use out_path in the config.ini file to specify the full path.
cd ../output/x_validate_removal

python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_solanaceae_odb10 \
-l $myDB/solanaceae_odb10 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_embryophyta_odb9 \
-l $myDB/embryophyta_odb9 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_embryophyta_odb10 \
-l $myDB/embryophyta_odb10 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_chlorophyta_odb10 \
-l $myDB/chlorophyta_odb10 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_viridiplantae_odb10 \
-l $myDB/viridiplantae_odb10 \
--mode prot \
-c 30 \
-t ./tmp;



python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_arthropoda_odb9 \
-l $myDB/arthropoda_odb9 \
--mode prot \
-c 30 \
-t ./tmp;


python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_bacteria_odb9 \
-l $myDB/bacteria_odb9 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_nematoda_odb9 \
-l $myDB/nematoda_odb9 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_protists_ensembl \
-l $myDB/protists_ensembl \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Rywal.removed.aa \
-o Rywal.removed.aa_metazoa_odb9 \
-l $myDB/metazoa_odb9 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i PW363.removed.aa \
-o PW363.removed.aa_solanaceae_odb10 \
-l $myDB/solanaceae_odb10 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i PW363.removed.aa \
-o PW363.removed.aa_embryophyta_odb9 \
-l $myDB/embryophyta_odb9 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i PW363.removed.aa \
-o PW363.removed.aa_embryophyta_odb10 \
-l $myDB/embryophyta_odb10 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i PW363.removed.aa \
-o PW363.removed.aa_chlorophyta_odb10 \
-l $myDB/chlorophyta_odb10 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i PW363.removed.aa \
-o PW363.removed.aa_viridiplantae_odb10 \
-l $myDB/viridiplantae_odb10 \
--mode prot \
-c 30 \
-t ./tmp;


python $myBUSCO \
-i Desiree.removed.aa \
-o Desiree.removed.aa_solanaceae_odb10 \
-l $myDB/solanaceae_odb10 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Desiree.removed.aa \
-o Desiree.removed.aa_embryophyta_odb9 \
-l $myDB/embryophyta_odb9 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Desiree.removed.aa \
-o Desiree.removed.aa_embryophyta_odb10 \
-l $myDB/embryophyta_odb10 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Desiree.removed.aa \
-o Desiree.removed.aa_chlorophyta_odb10 \
-l $myDB/chlorophyta_odb10 \
--mode prot \
-c 30 \
-t ./tmp;

python $myBUSCO \
-i Desiree.removed.aa \
-o Desiree.removed.aa_viridiplantae_odb10 \
-l $myDB/viridiplantae_odb10 \
--mode prot \
-c 30 \
-t ./tmp;


rm -rf ./tmp
rm -rf ./*/hmmer_output

cd ../../scripts/

rm ../output/x_validate_removal/Desiree.removed.aa
rm ../output/x_validate_removal/PW363.removed.aa
rm ../output/x_validate_removal/Rywal.removed.aa

