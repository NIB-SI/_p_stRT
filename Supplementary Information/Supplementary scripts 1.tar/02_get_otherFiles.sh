#!/bin/sh
# zagor

# see https://www.cyberciti.biz/howto/question/general/compress-file-unix-linux-cheat-sheet.php in the case you need to uncompress some data


# vecscreen
cp ../../_A_02.7_VecScreen/output/Desiree_vecscreen.tsv ../output/intermediate/Desiree/
cp ../../_A_02.7_VecScreen/output/PW363_vecscreen.tsv ../output/intermediate/PW363/
cp ../../_A_02.7_VecScreen/output//Rywal_vecscreen.tsv ../output/intermediate/Rywal/

# IPS
cp ../../_A_02.3_InterProScan/output/Desiree_IPS_filtered_aggregated_filtered.tsv ../output/intermediate/Desiree/
cp ../../_A_02.3_InterProScan/output/PW363_IPS_filtered_aggregated_filtered.tsv ../output/intermediate/PW363/
cp ../../_A_02.3_InterProScan/output/Rywal_IPS_filtered_aggregated_filtered.tsv ../output/intermediate/Rywal/

cat ../../_A_02.5_STARlong_matchAnnot/output/output_2_matchAnnot-parsed-txt/Desiree.tr.okay_DM_STARlong.Aligned.out.sorted.sam.matchAnnot.parsed.txt \
../../_A_02.5_STARlong_matchAnnot/output/output_2_matchAnnot-parsed-txt/Desiree.tr.okalt_DM_STARlong.Aligned.out.sorted.sam.matchAnnot.parsed.txt > ../output/intermediate/Desiree/Desiree.tr_DM_STARlong.Aligned.out.sorted.sam.matchAnnot.parsed.txt

cat ../../_A_02.5_STARlong_matchAnnot/output/output_2_matchAnnot-parsed-txt/PW363.tr.okay_DM_STARlong.Aligned.out.sorted.sam.matchAnnot.parsed.txt \
../../_A_02.5_STARlong_matchAnnot/output/output_2_matchAnnot-parsed-txt/PW363.tr.okalt_DM_STARlong.Aligned.out.sorted.sam.matchAnnot.parsed.txt > ../output/intermediate/PW363/PW363.tr_DM_STARlong.Aligned.out.sorted.sam.matchAnnot.parsed.txt

cat ../../_A_02.5_STARlong_matchAnnot/output/output_2_matchAnnot-parsed-txt/Rywal.tr.okay_DM_STARlong.Aligned.out.sorted.sam.matchAnnot.parsed.txt \
../../_A_02.5_STARlong_matchAnnot/output/output_2_matchAnnot-parsed-txt/Rywal.tr.okalt_DM_STARlong.Aligned.out.sorted.sam.matchAnnot.parsed.txt > ../output/intermediate/Rywal/Rywal.tr_DM_STARlong.Aligned.out.sorted.sam.matchAnnot.parsed.txt


# DIAMOND blastx
cp ../../_A_02.8_DIAMOND/output/Desiree.cds_solanumTuberosum.out.ENCHformat_top1.tsv ../output/intermediate/Desiree/01_Desiree.cds_solanumTuberosum.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Desiree.tr_solanumTuberosum.out.ENCHformat_top1.tsv ../output/intermediate/Desiree/02_Desiree.tr_solanumTuberosum.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/Desiree_rescued.tr_solanumTuberosum.out.ENCHformat_top1.tsv >> ../output/intermediate/Desiree/02_Desiree.tr_solanumTuberosum.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Desiree.cds_Solanaceae.out.ENCHformat_top1.tsv ../output/intermediate/Desiree/03_Desiree.cds_Solanaceae.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Desiree.tr_Solanaceae.out.ENCHformat_top1.tsv ../output/intermediate/Desiree/04_Desiree.tr_Solanaceae.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/Desiree_rescued.tr_Solanaceae.out.ENCHformat_top1.tsv >> ../output/intermediate/Desiree/04_Desiree.tr_Solanaceae.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Desiree.cds_SP_TrEMBL_plants.out.ENCHformat_top1.tsv ../output/intermediate/Desiree/05_Desiree.cds_SP_TrEMBL_plants.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Desiree.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv ../output/intermediate/Desiree/06_Desiree.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/Desiree_rescued.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv >> ../output/intermediate/Desiree/06_Desiree.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Desiree.cds_SwissProt_TrEMBL.out.ENCHformat_top1.tsv ../output/intermediate/Desiree/07_Desiree.cds_SwissProt_TrEMBL.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Desiree.tr_SwissProt_TrEMBL.out.ENCHformat_top1.tsv ../output/intermediate/Desiree/08_Desiree.tr_SwissProt_TrEMBL.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/Desiree_rescued.tr_sprot_trembl.out.ENCHformat_top1.tsv >> ../output/intermediate/Desiree/08_Desiree.tr_SwissProt_TrEMBL.out.ENCHformat_top1.tsv


cp ../../_A_02.8_DIAMOND/output/PW363.cds_solanumTuberosum.out.ENCHformat_top1.tsv ../output/intermediate/PW363/01_PW363.cds_solanumTuberosum.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/PW363.tr_solanumTuberosum.out.ENCHformat_top1.tsv ../output/intermediate/PW363/02_PW363.tr_solanumTuberosum.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/PW363_rescued.tr_solanumTuberosum.out.ENCHformat_top1.tsv >> ../output/intermediate/PW363/02_PW363.tr_solanumTuberosum.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/PW363.cds_Solanaceae.out.ENCHformat_top1.tsv ../output/intermediate/PW363/03_PW363.cds_Solanaceae.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/PW363.tr_Solanaceae.out.ENCHformat_top1.tsv ../output/intermediate/PW363/04_PW363.tr_Solanaceae.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/PW363_rescued.tr_Solanaceae.out.ENCHformat_top1.tsv >> ../output/intermediate/PW363/04_PW363.tr_Solanaceae.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/PW363.cds_SP_TrEMBL_plants.out.ENCHformat_top1.tsv ../output/intermediate/PW363/05_PW363.cds_SP_TrEMBL_plants.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/PW363.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv ../output/intermediate/PW363/06_PW363.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/PW363_rescued.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv >> ../output/intermediate/PW363/06_PW363.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/PW363.cds_SwissProt_TrEMBL.out.ENCHformat_top1.tsv ../output/intermediate/PW363/07_PW363.cds_SwissProt_TrEMBL.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/PW363.tr_SwissProt_TrEMBL.out.ENCHformat_top1.tsv ../output/intermediate/PW363/08_PW363.tr_SwissProt_TrEMBL.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/PW363_rescued.tr_sprot_trembl.out.ENCHformat_top1.tsv >> ../output/intermediate/PW363/08_PW363.tr_SwissProt_TrEMBL.out.ENCHformat_top1.tsv


cp ../../_A_02.8_DIAMOND/output/Rywal.cds_solanumTuberosum.out.ENCHformat_top1.tsv ../output/intermediate/Rywal/01_Rywal.cds_solanumTuberosum.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Rywal.tr_solanumTuberosum.out.ENCHformat_top1.tsv ../output/intermediate/Rywal/02_Rywal.tr_solanumTuberosum.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/Rywal_rescued.tr_solanumTuberosum.out.ENCHformat_top1.tsv >> ../output/intermediate/Rywal/02_Rywal.tr_solanumTuberosum.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Rywal.cds_Solanaceae.out.ENCHformat_top1.tsv ../output/intermediate/Rywal/03_Rywal.cds_Solanaceae.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Rywal.tr_Solanaceae.out.ENCHformat_top1.tsv ../output/intermediate/Rywal/04_Rywal.tr_Solanaceae.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/Rywal_rescued.tr_Solanaceae.out.ENCHformat_top1.tsv >> ../output/intermediate/Rywal/04_Rywal.tr_Solanaceae.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Rywal.cds_Swissprot_TrEMBL_plants.out.ENCHformat_top1.tsv ../output/intermediate/Rywal/05_Rywal.cds_SP_TrEMBL_plants.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Rywal.tr_Swissprot_TrEMBL_plants.out.ENCHformat_top1.tsv ../output/intermediate/Rywal/06_Rywal.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/Rywal_rescued.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv >> ../output/intermediate/Rywal/06_Rywal.tr_SP_TrEMBL_plants.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Rywal.cds_sprot_trembl.out.ENCHformat_top1.tsv ../output/intermediate/Rywal/07_Rywal.cds_SwissProt_TrEMBL.out.ENCHformat_top1.tsv

cp ../../_A_02.8_DIAMOND/output/Rywal.tr_sprot_trembl.out.ENCHformat_top1.tsv ../output/intermediate/Rywal/08_Rywal.tr_SwissProt_TrEMBL.out.ENCHformat_top1.tsv
sed 1d ../../_A_02.8_DIAMOND/output/Rywal_rescued.tr_sprot_trembl.out.ENCHformat_top1.tsv >> ../output/intermediate/Rywal/08_Rywal.tr_SwissProt_TrEMBL.out.ENCHformat_top1.tsv
