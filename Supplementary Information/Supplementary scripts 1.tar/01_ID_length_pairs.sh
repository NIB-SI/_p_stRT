#!/bin/sh
# zagor

# see https://www.cyberciti.biz/howto/question/general/compress-file-unix-linux-cheat-sheet.php in the case you need to uncompress some data


mkdir ../output/intermediate/
mkdir ../output/intermediate/Desiree/
mkdir ../output/intermediate/PW363/
mkdir ../output/intermediate/Rywal/

mkdir ../output/Desiree/
mkdir ../output/PW363/
mkdir ../output/Rywal/

# mkdir ../output/Desiree/keep
# mkdir ../output/PW363/keep
# mkdir ../output/Rywal/keep
# mkdir ../output/Desiree/remove
# mkdir ../output/PW363/remove
# mkdir ../output/Rywal/remove

cat ../../_A_01_evigene/intermediate_tr2aacds_Desiree/okayset/all.okay.tr ../../_A_01_evigene/intermediate_tr2aacds_Desiree/okayset/all.okalt.tr  | seqkit fx2tab --length --name --header-line > ../output/intermediate/Desiree/Desiree.tr_lengths.tsv
cat ../../_A_01_evigene/intermediate_tr2aacds_Desiree/okayset/all.okay.cds ../../_A_01_evigene/intermediate_tr2aacds_Desiree/okayset/all.okalt.cds  | seqkit fx2tab --length --name --header-line > ../output/intermediate/Desiree/Desiree.cds_lengths.tsv

cat ../../_A_01_evigene/intermediate_tr2aacds_PW363/okayset/all.okay.tr ../../_A_01_evigene/intermediate_tr2aacds_PW363/okayset/all.okalt.tr  | seqkit fx2tab --length --name --header-line > ../output/intermediate/PW363/PW363.tr_lengths.tsv
cat ../../_A_01_evigene/intermediate_tr2aacds_PW363/okayset/all.okay.cds ../../_A_01_evigene/intermediate_tr2aacds_PW363/okayset/all.okalt.cds  | seqkit fx2tab --length --name --header-line > ../output/intermediate/PW363/PW363.cds_lengths.tsv

cat .../../_A_01_evigene/intermediate_tr2aacds_Rywal/okayset/all.okay.tr .../../_A_01_evigene/intermediate_tr2aacds_Rywal/okayset/all.okalt.tr  | seqkit fx2tab --length --name --header-line > ../output/intermediate/Rywal/Rywal.tr_lengths.tsv
cat .../../_A_01_evigene/intermediate_tr2aacds_Rywal/okayset/all.okay.cds .../../_A_01_evigene/intermediate_tr2aacds_Rywal/okayset/all.okalt.cds  | seqkit fx2tab --length --name --header-line > ../output/intermediate/Rywal/Rywal.cds_lengths.tsv
