#!/bin/sh
# zagor

# see https://www.cyberciti.biz/howto/question/general/compress-file-unix-linux-cheat-sheet.php in the case you need to uncompress some data


# apt-get install dos2unix

mkdir ../output/summary/

dos2unix ../output/Desiree/Desiree_tr.3_keep_IDs.tsv
dos2unix ../output/Desiree/Desiree_tr.3_utrorf_keep_IDs.tsv
dos2unix ../output/PW363/PW363_tr.3_keep_IDs.tsv
dos2unix ../output/PW363/PW363_tr.3_utrorf_keep_IDs.tsv
dos2unix ../output/Rywal/Rywal_tr.3_keep_IDs.tsv
dos2unix ../output/Rywal/Rywal_tr.3_utrorf_keep_IDs.tsv

cat ../output/Desiree/Desiree_tr.3_keep_IDs.tsv ../output/Desiree/Desiree_tr.3_utrorf_keep_IDs.tsv > ../output/summary/Desiree.cds.annot.IDs
sort ../output/summary/Desiree.cds.annot.IDs > ../output/summary/Desiree.cds.annot.IDs.txt
rm ../output/summary/Desiree.cds.annot.IDs

cat ../output/PW363/PW363_tr.3_keep_IDs.tsv ../output/PW363/PW363_tr.3_utrorf_keep_IDs.tsv > ../output/summary/PW363.cds.annot.IDs
sort ../output/summary/PW363.cds.annot.IDs > ../output/summary/PW363.cds.annot.IDs.txt
rm ../output/summary/PW363.cds.annot.IDs

cat ../output/Rywal/Rywal_tr.3_keep_IDs.tsv ../output/Rywal/Rywal_tr.3_utrorf_keep_IDs.tsv > ../output/summary/Rywal.cds.annot.IDs
sort ../output/summary/Rywal.cds.annot.IDs > ../output/summary/Rywal.cds.annot.IDs.txt
rm ../output/summary/Rywal.cds.annot.IDs

cp ../output/summary/Desiree.cds.annot.IDs.txt ../output/summary/Desiree.aa.annot.IDs.txt;
cp ../output/summary/PW363.cds.annot.IDs.txt ../output/summary/PW363.aa.annot.IDs.txt;
cp ../output/summary/Rywal.cds.annot.IDs.txt ../output/summary/Rywal.aa.annot.IDs.txt;

grep -v "utrorf" ../output/summary/Desiree.cds.annot.IDs.txt > ../output/summary/Desiree.tr.annot.IDs.txt
grep -v "utrorf" ../output/summary/PW363.cds.annot.IDs.txt > ../output/summary/PW363.tr.annot.IDs.txt
grep -v "utrorf" ../output/summary/Rywal.cds.annot.IDs.txt > ../output/summary/Rywal.tr.annot.IDs.txt
