#!/bin/sh
# zagor

# see https://www.cyberciti.biz/howto/question/general/compress-file-unix-linux-cheat-sheet.php in the case you need to uncompress some data


   # -i   input filename for db1 in fasta format, required
   # -i2  input filename for db2 in fasta format, required
   # -o   output filename, required
   # -M   memory limit (in MB) for the program, default 800; 0 for unlimitted;
   # -T   number of threads, default 1; with 0, all CPUs will be used
   # -n   word_length, default 5, see user's guide for choosing it
   # -aS  alignment coverage for the shorter sequence, default 0.0
        # if set to 0.9, the alignment must covers 90% of the sequence
   # -p   1 or 0, default 0
        # if set to 1, print alignment overlap in .clstr file
   # -g   1 or 0, default 0
        # by cd-hit's default algorithm, a sequence is clustered to the first
        # cluster that meet the threshold (fast cluster). If set to 1, the program
        # will cluster it into the most similar cluster that meet the threshold
        # (accurate but slow mode)
        # but either 1 or 0 won't change the representatives of final clusters
   # -bak write backup cluster file (1 or 0, default 0)

# decision -aS 0.51 -c 0.70

cdhit-2d -i ../intermediate_3_sequence-sets/stCuSTr-R_aa_representatives.fasta \
-i2 ../intermediate_3_sequence-sets/stCuSTr-R_aa_alternatives.fasta \
-o ../intermediate_4_cdhit-2d/stCuSTr-R_aa_local_aS.51_c.70 \
-G 0 -n 4 -g 1 -c 0.70 -aS 0.51 -p 1 -bak 1 -d 200 \
-M 0 -T 24;

cdhit-2d -i ../intermediate_3_sequence-sets/stCuSTr-P_aa_representatives.fasta \
-i2 ../intermediate_3_sequence-sets/stCuSTr-P_aa_alternatives.fasta \
-o ../intermediate_4_cdhit-2d/stCuSTr-P_aa_local_aS.51_c.70 \
-G 0 -n 4 -g 1 -c 0.70 -aS 0.51 -p 1 -bak 1 -d 200 \
-M 0 -T 24;

cdhit-2d -i ../intermediate_3_sequence-sets/stCuSTr-D_aa_representatives.fasta \
-i2 ../intermediate_3_sequence-sets/stCuSTr-D_aa_alternatives.fasta \
-o ../intermediate_4_cdhit-2d/stCuSTr-D_aa_local_aS.51_c.70 \
-G 0 -n 4 -g 1 -c 0.70 -aS 0.51 -p 1 -bak 1 -d 200 \
-M 0 -T 24;


