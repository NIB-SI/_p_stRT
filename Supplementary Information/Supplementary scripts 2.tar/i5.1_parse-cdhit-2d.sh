#!/bin/sh
# zagor

# see https://www.cyberciti.biz/howto/question/general/compress-file-unix-linux-cheat-sheet.php in the case you need to uncompress some data


grep "... at " ../intermediate_4_cdhit-2d/stCuSTr-D_aa_local_aS.51_c.70.bak.clstr | sed 's/... at /|/g' | cut -f1 -d '|' | sed 's#aa, >#\t#g' > ../output/fasta_1B_alt-per-cv/stCuSTr-D_aa_altKept.3cols;
cut -f3 ../output/fasta_1B_alt-per-cv/stCuSTr-D_aa_altKept.3cols > ../output/fasta_1B_alt-per-cv/stCuSTr-D_aa_keptAlt.IDs;
grep "... \*" ../intermediate_4_cdhit-2d/stCuSTr-D_aa_local_aS.51_c.70.bak.clstr | sed 's/... \*/|/g' | cut -f1 -d '|' | sed 's#aa, >#\t#g' > ../output/fasta_1A_rep-per-cv/stCuSTr-D_aa_rep.3cols;

grep "... at " ../intermediate_4_cdhit-2d/stCuSTr-P_aa_local_aS.51_c.70.bak.clstr | sed 's/... at /|/g' | cut -f1 -d '|' | sed 's#aa, >#\t#g' > ../output/fasta_1B_alt-per-cv/stCuSTr-P_aa_altKept.3cols;
cut -f3 ../output/fasta_1B_alt-per-cv/stCuSTr-P_aa_altKept.3cols > ../output/fasta_1B_alt-per-cv/stCuSTr-P_aa_keptAlt.IDs;
grep "... \*" ../intermediate_4_cdhit-2d/stCuSTr-P_aa_local_aS.51_c.70.bak.clstr | sed 's/... \*/|/g' | cut -f1 -d '|' | sed 's#aa, >#\t#g' > ../output/fasta_1A_rep-per-cv/stCuSTr-P_aa_rep.3cols;

grep "... at " ../intermediate_4_cdhit-2d/stCuSTr-R_aa_local_aS.51_c.70.bak.clstr | sed 's/... at /|/g' | cut -f1 -d '|' | sed 's#aa, >#\t#g' > ../output/fasta_1B_alt-per-cv/stCuSTr-R_aa_altKept.3cols;
cut -f3 ../output/fasta_1B_alt-per-cv/stCuSTr-R_aa_altKept.3cols > ../output/fasta_1B_alt-per-cv/stCuSTr-R_aa_keptAlt.IDs;
grep "... \*" ../intermediate_4_cdhit-2d/stCuSTr-R_aa_local_aS.51_c.70.bak.clstr | sed 's/... \*/|/g' | cut -f1 -d '|' | sed 's#aa, >#\t#g' > ../output/fasta_1A_rep-per-cv/stCuSTr-R_aa_rep.3cols;

tar -zcvf ../intermediate_4_cdhit-2d.tar.gz ../intermediate_4_cdhit-2d/
rm -rf ../intermediate_4_cdhit-2d/
