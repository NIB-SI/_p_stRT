#!/usr/bin/perl -w
use strict;

### This script prepares the Pajek formatted .net file for weak components.

open(FILE, "../intermediate_1_preparing-files/3cv_evigene-headers_table-format.txt"); my @uno = <FILE>; close(FILE); chomp(@uno);
my %idConverter = ();
foreach my $line (@uno)
{   $line =~ s/\s+$//;
    unless ($line eq '')
		{   my @spl = split(/\t/, $line);
						$idConverter{$spl[0]} = '';
						$idConverter{$spl[1]} = '';
		}
}

open(OTH, ">../intermediate_2_prepare-network/3cv_evigene-header-network_unfiltered.net");
print OTH ('*Vertices '.keys(%idConverter)."\n");
my $count = 1;
foreach my $id (sort keys %idConverter)
{   print OTH ($count." \"$id\"\n");
    $idConverter{$id} = $count;
    $count++;
}

print OTH ('*Arcs'."\n");
## dont forget to delete the header from blast result file
foreach my $line (@uno)
{   $line =~ s/\s+$//;
    unless ($line eq '')
		{   my @spl = split(/\t/, $line);
		    print OTH ($idConverter{$spl[0]}." ".$idConverter{$spl[1]}."\n");
		}
}
close(OTH);
