#!/usr/bin/perl -w
use strict;

my %seqAA = (); my %seqCD = (); my %seqTR = ();
open(FILE, "../intermediate_1_preparing-files/3cvs_sequences_keep.txt"); my @f2 = <FILE>; close(FILE); chomp(@f2);
foreach my $line (@f2)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    $seqTR{$s[0]} = $s[1];
				$seqCD{$s[0]} = $s[2];
		    $seqAA{$s[0]} = $s[3];
		}
}

open(FILE, "../intermediate_2_prepare-network/3cv_evigene-header-network_unfiltered_weak-components_perWC-filtered_with-rep.txt"); my @f = <FILE>; close(FILE); chomp(@f);

open(REPA, ">../intermediate_2_prepare-network/stCuSTr-3cv_aa_representatives.fasta");
open(REPC, ">../intermediate_2_prepare-network/stCuSTr-3cv_cds_representatives.fasta");
open(REPT, ">../intermediate_2_prepare-network/stCuSTr-3cv_tr_representatives.fasta");

open(ALTA, ">../intermediate_2_prepare-network/stCuSTr-3cv_aa_alternatives.fasta");
open(ALTC, ">../intermediate_2_prepare-network/stCuSTr-3cv_cds_alternatives.fasta");
open(ALTT, ">../intermediate_2_prepare-network/stCuSTr-3cv_tr_alternatives.fasta");

open(UTRA, ">../intermediate_2_prepare-network/stCuSTr-3cv_aa_utrorf.fasta");
open(UTRC, ">../intermediate_2_prepare-network/stCuSTr-3cv_cds_utrorf.fasta");
open(UTRT, ">../intermediate_2_prepare-network/stCuSTr-3cv_tr_utrorf.fasta");

foreach my $line (@f)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    if ($s[4] eq 'representative')
				{   print REPA (">$s[3]\t$s[0]\t".$seqAA{'>'.$s[3]}."\n");
				    print REPC (">$s[3]\t$s[0]\t".$seqCD{'>'.$s[3]}."\n");
						print REPT (">$s[3]\t$s[0]\t".$seqTR{'>'.$s[3]}."\n");
				}
				elsif ($s[4] eq 'possible-alt')
				{   print ALTA (">$s[3]\t$s[0]\t".$seqAA{'>'.$s[3]}."\n");
				    print ALTC (">$s[3]\t$s[0]\t".$seqCD{'>'.$s[3]}."\n");
						print ALTT (">$s[3]\t$s[0]\t".$seqTR{'>'.$s[3]}."\n");
				}
				elsif ($s[4] eq 'utrorf')
				{   print UTRA (">$s[3]\t$s[0]\t".$seqAA{'>'.$s[3]}."\n");
				    print UTRC (">$s[3]\t$s[0]\t".$seqCD{'>'.$s[3]}."\n");
						print UTRT (">$s[3]\t$s[0]\t".$seqTR{'>'.$s[3]}."\n");
				}
				else
				{   print $line."\n";
				}
		}
}
