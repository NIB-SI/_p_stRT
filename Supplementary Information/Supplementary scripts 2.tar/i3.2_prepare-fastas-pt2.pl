#!/usr/bin/perl -w
use strict;

opendir (DIR, "../intermediate_2_prepare-network/"); my @txts = grep(/\.fasta$/, readdir(DIR)); closedir (DIR); chomp(@txts);
foreach my $file (@txts)
{   $file =~ s/\s+$//; open(FILE, "../intermediate_2_prepare-network/$file"); my @file = <FILE>; close(FILE); chomp(@file);

		my $de = $file; $de =~ s/stCuSTr-3cv_/stCuSTr-D_/; open(DE, ">../intermediate_3_sequence-sets/$de");
		my $pw = $file; $pw =~ s/stCuSTr-3cv_/stCuSTr-P_/; open(PW, ">../intermediate_3_sequence-sets/$pw");
		my $ry = $file; $ry =~ s/stCuSTr-3cv_/stCuSTr-R_/; open(RY, ">../intermediate_3_sequence-sets/$ry");

		foreach my $line (@file)
		{   $line =~ s/\s+$//;
		    unless ($line eq "")
				{   my @tmp = split(/\t/, $line); my $new = $tmp[0]."\n".$tmp[2];
				    if (@tmp == 1)
						{   print $line."\n";
						}
					  if ($line =~ /stCuSTr-D_/)   {   print DE ($new."\n");   }
				    elsif ($line =~ /stCuSTr-P_/)   {   print PW ($new."\n");   }
						elsif ($line =~ /stCuSTr-R_/)   {   print RY ($new."\n");   }
						else
						{   print $line."\n";
						}
				}
		}
		close(DE); close(PW); close(RY);
		# unlink("../intermediate_2_prepare-network/".$file);
}
