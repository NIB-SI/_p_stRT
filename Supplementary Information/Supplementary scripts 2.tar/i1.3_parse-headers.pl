#!/usr/bin/perl -w
use strict;

### This script parses the Evigene fasta headers into binary connections between nodes mentioned within the header.
### It works on headers from the okay and okalt sets, not if you include headers from the dropped also!

open(FILE, "../intermediate_1_preparing-files/3cv_evigene-headers.txt"); my @file = <FILE>; close(FILE); chomp(@file);
open(END, ">../intermediate_1_preparing-files/3cv_evigene-headers_table-format.txt");

foreach my $line (@file)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @split = split(/\t/, $line);
		    $split[0] =~ s/>//;
				print END ($split[0]."\t".$split[0]."\n");

				if ($split[1] =~ / /)
				{   my @mod = split(/ /, $split[1]);
				    $split[1] = $mod[1];
				}

				my @an = split(/;/, $split[1]);
				if (@an == 2)
				{   $an[0] =~ s/evgclass=//;
						if ($line =~ /match/)
						{   my @th1 = split(/match:/, $an[0]);
						    my @th2 = split(/,/, $th1[1]);
								print END ($split[0]."\t".$th2[0]."\n");
								my @th3 = split(/\//, $th2[1]);
								if (@th3 == 4)
								{   print END ($split[0]."\t".$th3[3]."\n");
								    print END ($th2[0]."\t".$th3[3]."\n");
								}
					  }
				}
				elsif (@an == 6)
				{   $an[5] =~ s/evgclass=//;
						if ($line =~ /match/)
						{   my @th1 = split(/match:/, $an[5]);
						    my @th2 = split(/,/, $th1[1]);
								print END ($split[0]."\t".$th2[0]."\n");
								my @th3 = split(/\//, $th2[1]);
								if (@th3 == 4)
								{   print END ($split[0]."\t".$th3[3]."\n");
								    print END ($th2[0]."\t".$th3[3]."\n");
								}
					  }
				}
		}
}
close(END);

my %uniqConn = ();
open(FILE, "../intermediate_1_preparing-files/3cv_evigene-headers_table-format.txt"); my @file2 = <FILE>; close(FILE); chomp(@file2);
open(END, ">../intermediate_1_preparing-files/3cv_evigene-headers_table-format.txt");
foreach my $line (@file2)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   $uniqConn{$line} = 0;
		}
}
foreach my $un (sort keys %uniqConn)
{   print END ($un."\n");
}
close(END);
