#!/bin/sh
# zagor

# see https://www.cyberciti.biz/howto/question/general/compress-file-unix-linux-cheat-sheet.php in the case you need to uncompress some data


dos2unix ../output/3cv_cdhit-2d_weak-components_alias.txt

# move intact files
mv ../intermediate_3_sequence-sets/*_utrorf.fasta ../output/fasta_3A_utrorfs-per-cv

# get elimintade aa IDs
grep ">" ../intermediate_4_cdhit-2d/stCuSTr-D_aa_local_aS.51_c.70 | cut -f1 -d " " | sed 's/>//g' > ../output/fasta_3B_eliminated-per-cv/stCuSTr-D_aa_eliminated.IDs;
grep ">" ../intermediate_4_cdhit-2d/stCuSTr-P_aa_local_aS.51_c.70 | cut -f1 -d " " | sed 's/>//g' > ../output/fasta_3B_eliminated-per-cv/stCuSTr-P_aa_eliminated.IDs;
grep ">" ../intermediate_4_cdhit-2d/stCuSTr-R_aa_local_aS.51_c.70 | cut -f1 -d " " | sed 's/>//g' > ../output/fasta_3B_eliminated-per-cv/stCuSTr-R_aa_eliminated.IDs;

# remove descriptions
# cut -f1 -d " " ../output/fasta_3B_eliminated-per-cv/stCuSTr-D_aa_eliminated.fasta | sponge ../output/fasta_3B_eliminated-per-cv/stCuSTr-D_aa_eliminated.fasta;
# cut -f1 -d " " ../output/fasta_3B_eliminated-per-cv/stCuSTr-P_aa_eliminated.fasta | sponge ../output/fasta_3B_eliminated-per-cv/stCuSTr-P_aa_eliminated.fasta;
# cut -f1 -d " " ../output/fasta_3B_eliminated-per-cv/stCuSTr-R_aa_eliminated.fasta | sponge ../output/fasta_3B_eliminated-per-cv/stCuSTr-R_aa_eliminated.fasta;
# add descriptions

for f in ../intermediate_3_sequence-sets/stCuSTr-D_*alternatives.fasta
do
    tmp=${f##*/}
    echo "${f##*/}"
    xargs faidx -d ' ' $f < \
    ../output/fasta_3B_eliminated-per-cv/stCuSTr-D_aa_eliminated.IDs > \
    ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.fasta 2> \
    ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.err.txt
    awk 'NR==FNR{a[$1]=$2;next}
     NF==2{$2=a[$2]; print ">" $2;next}
     1' FS='\t' ../output/3cv_cdhit-2d_weak-components_alias.txt FS='>' ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.fasta | sponge ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.fasta
done;

for f in ../intermediate_3_sequence-sets/stCuSTr-P_*alternatives.fasta
do
    tmp=${f##*/}
    echo "${f##*/}"
    xargs faidx -d ' ' $f < \
    ../output/fasta_3B_eliminated-per-cv/stCuSTr-P_aa_eliminated.IDs > \
    ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.fasta 2> \
    ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.err.txt
    awk 'NR==FNR{a[$1]=$2;next}
     NF==2{$2=a[$2]; print ">" $2;next}
     1' FS='\t' ../output/3cv_cdhit-2d_weak-components_alias.txt FS='>' ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.fasta | sponge ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.fasta
done;

for f in ../intermediate_3_sequence-sets/stCuSTr-R_*alternatives.fasta
do
    tmp=${f##*/}
    echo "${f##*/}"
    xargs faidx -d ' ' $f < \
    ../output/fasta_3B_eliminated-per-cv/stCuSTr-R_aa_eliminated.IDs > \
    ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.fasta 2> \
    ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.err.txt
    awk 'NR==FNR{a[$1]=$2;next}
     NF==2{$2=a[$2]; print ">" $2;next}
     1' FS='\t' ../output/3cv_cdhit-2d_weak-components_alias.txt FS='>' ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.fasta | sponge ../output/fasta_3B_eliminated-per-cv/${tmp%.*}_eliminated.fasta
done;

# all size 0
rm ../output/fasta_3B_eliminated-per-cv/*_eliminated.err.txt;
for f in ../output/fasta_3B_eliminated-per-cv/*_eliminated.fasta
do
    grep ">" $f | wc -l
done;

for f in ../output/fasta_3B_eliminated-per-cv/*_aa_eliminated.IDs
do
    wc -l $f
done;
rm ../output/fasta_3B_eliminated-per-cv/*_aa_eliminated.IDs;


### representatives
# remove and replace description # # https://bioinf.shenwei.me/seqkit/usage/#replace not working, therefore awk

for f in ../intermediate_3_sequence-sets/*_representatives.fasta
do
    tmp=${f##*/}
    echo "${f##*/}"
    cut -f1 -d ' ' $f > ../output/fasta_1A_rep-per-cv/"${f##*/}"
    awk 'NR==FNR{a[$1]=$2;next}
     NF==2{$2=a[$2]; print ">" $2;next}
     1' FS='\t' ../output/3cv_cdhit-2d_weak-components_alias.txt FS='>' ../output/fasta_1A_rep-per-cv/"${f##*/}" | sponge ../output/fasta_1A_rep-per-cv/"${f##*/}"
done;

for f in ../output/fasta_1A_rep-per-cv/*fasta
do
    grep ">" $f | wc -l
done;


# kept alternatives
for f in ../intermediate_3_sequence-sets/stCuSTr-R_*alternatives.fasta
do
    tmp=${f##*/}
    echo ${tmp%.*} # "${f##*/}"
    xargs faidx -d ' ' $f < \
    ../output/fasta_1B_alt-per-cv/stCuSTr-R_aa_keptAlt.IDs > \
    ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta 2> \
    ../output/fasta_1B_alt-per-cv/${tmp%.*}.err.txt
    awk 'NR==FNR{a[$1]=$2;next}
     NF==2{$2=a[$2]; print ">" $2;next}
     1' FS='\t' ../output/3cv_cdhit-2d_weak-components_alias.txt FS='>' ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta | sponge ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta
    grep ">" ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta | wc -l
done;

for f in ../intermediate_3_sequence-sets/stCuSTr-P_*alternatives.fasta
do
    tmp=${f##*/}
    echo ${tmp%.*} # "${f##*/}"
    xargs faidx -d ' ' $f < \
    ../output/fasta_1B_alt-per-cv/stCuSTr-P_aa_keptAlt.IDs > \
    ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta 2> \
    ../output/fasta_1B_alt-per-cv/${tmp%.*}.err.txt
    awk 'NR==FNR{a[$1]=$2;next}
     NF==2{$2=a[$2]; print ">" $2;next}
     1' FS='\t' ../output/3cv_cdhit-2d_weak-components_alias.txt FS='>' ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta | sponge ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta
    grep ">" ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta | wc -l
done;

for f in ../intermediate_3_sequence-sets/stCuSTr-D_*alternatives.fasta
do
    tmp=${f##*/}
    echo ${tmp%.*} # "${f##*/}"
    xargs faidx -d ' ' $f < \
    ../output/fasta_1B_alt-per-cv/stCuSTr-D_aa_keptAlt.IDs > \
    ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta 2> \
    ../output/fasta_1B_alt-per-cv/${tmp%.*}.err.txt
    awk 'NR==FNR{a[$1]=$2;next}
     NF==2{$2=a[$2]; print ">" $2;next}
     1' FS='\t' ../output/3cv_cdhit-2d_weak-components_alias.txt FS='>' ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta | sponge ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta
    grep ">" ../output/fasta_1B_alt-per-cv/${tmp%.*}.fasta | wc -l
done;

rm ../output/fasta_1B_alt-per-cv/*_aa_altKept.3cols;
rm ../output/fasta_1B_alt-per-cv/*_aa_keptAlt.IDs;
rm ../output/fasta_1B_alt-per-cv/*.err.txt;
# rm ../output/fasta_1A_rep-per-cv/*_aa_rep.3cols;
rm ../intermediate_3_sequence-sets/*fai;

# with descriptions
cat ../output/fasta_1A_rep-per-cv/stCuSTr-D_aa_representatives.fasta ../output/fasta_1B_alt-per-cv/stCuSTr-D_aa_alternatives.fasta > ../output/fasta_2_all-per-cv/stCuSTr-D_aa_all.fasta;
cat ../output/fasta_1A_rep-per-cv/stCuSTr-D_cds_representatives.fasta ../output/fasta_1B_alt-per-cv/stCuSTr-D_cds_alternatives.fasta > ../output/fasta_2_all-per-cv/stCuSTr-D_cds_all.fasta;
cat ../output/fasta_1A_rep-per-cv/stCuSTr-D_tr_representatives.fasta ../output/fasta_1B_alt-per-cv/stCuSTr-D_tr_alternatives.fasta > ../output/fasta_2_all-per-cv/stCuSTr-D_tr_all.fasta;

cat ../output/fasta_1A_rep-per-cv/stCuSTr-P_aa_representatives.fasta ../output/fasta_1B_alt-per-cv/stCuSTr-P_aa_alternatives.fasta > ../output/fasta_2_all-per-cv/stCuSTr-P_aa_all.fasta;
cat ../output/fasta_1A_rep-per-cv/stCuSTr-P_cds_representatives.fasta ../output/fasta_1B_alt-per-cv/stCuSTr-P_cds_alternatives.fasta > ../output/fasta_2_all-per-cv/stCuSTr-P_cds_all.fasta;
cat ../output/fasta_1A_rep-per-cv/stCuSTr-P_tr_representatives.fasta ../output/fasta_1B_alt-per-cv/stCuSTr-P_tr_alternatives.fasta > ../output/fasta_2_all-per-cv/stCuSTr-P_tr_all.fasta;

cat ../output/fasta_1A_rep-per-cv/stCuSTr-R_aa_representatives.fasta ../output/fasta_1B_alt-per-cv/stCuSTr-R_aa_alternatives.fasta > ../output/fasta_2_all-per-cv/stCuSTr-R_aa_all.fasta;
cat ../output/fasta_1A_rep-per-cv/stCuSTr-R_cds_representatives.fasta ../output/fasta_1B_alt-per-cv/stCuSTr-R_cds_alternatives.fasta > ../output/fasta_2_all-per-cv/stCuSTr-R_cds_all.fasta;
cat ../output/fasta_1A_rep-per-cv/stCuSTr-R_tr_representatives.fasta ../output/fasta_1B_alt-per-cv/stCuSTr-R_tr_alternatives.fasta > ../output/fasta_2_all-per-cv/stCuSTr-R_tr_all.fasta;

cut -f 6,2,8,4,7 ../output/3cv_cdhit-2d_weak-components.txt > ../output/3cv_cdhit-2d_weak-components_ZR.txt
sed '1d' ../output/3cv_cdhit-2d_weak-components_ZR.txt | sponge ../output/3cv_cdhit-2d_weak-components_ZR.txt
awk 'BEGIN {FS="\t";OFS="\t"} {print $3, $1, $5, $2, $4}' ../output/3cv_cdhit-2d_weak-components_ZR.txt | sponge ../output/3cv_cdhit-2d_weak-components_ZR.txt


for file in ../output/fasta_1A_rep-per-cv/*.fasta
do
    gzip $file
done

for file in ../output/fasta_1B_alt-per-cv/*.fasta
do
    gzip $file
done


for file in ../output/fasta_2_all-per-cv/*.fasta
do
    gzip $file
done

tar -zcvf ../output/fasta_3A_utrorfs-per-cv.tar.gz ../output/fasta_3A_utrorfs-per-cv
tar -zcvf ../output/fasta_3B_eliminated-per-cv.tar.gz ../output/fasta_3B_eliminated-per-cv

pigz ../output/3cv_cdhit-2d_weak-components.txt
pigz ../output/3cv_cdhit-2d_weak-components_alias.txt

