#!/usr/bin/perl -w
use strict;

my %status = ();
### status according to sequence existence
open(FILE, "../intermediate_1_preparing-files/3cvs_sequences_discard.txt"); my @f2 = <FILE>; close(FILE); chomp(@f2);
foreach my $line (@f2)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line); $s[0] =~ s/>//; $status{$s[0]} = 'discard';
		}
}
open(FILE, "../intermediate_1_preparing-files/3cvs_sequences_keep.txt"); my @f4 = <FILE>; close(FILE); chomp(@f4);
foreach my $line (@f4)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line); $s[0] =~ s/>//; $status{$s[0]} = 'keep';
		}
}

### status according to IPR scan, Diamond etc.
open(FILE, "../intermediate_1_preparing-files/3cv_post-ev-filtered_discard.txt"); my @f1 = <FILE>; close(FILE); chomp(@f1);
foreach my $line (@f1)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    if (exists($status{$s[0]}))
				{   $status{$s[0]} = 'discard';
				}
				if (exists($status{$s[1]}))
				{   $status{$s[1]} = 'discard';
				}
		}
}

### this one was not used; all it would do, was cause problems with the utrorf regions
# open(FILE, "../intermediate_1_preparing-files/3cv_post-ev-filtered_keep.txt"); my @f3 = <FILE>; close(FILE); chomp(@f3);

### correcting for utrorf regions
foreach my $k (sort keys %status)
{   if ($k =~ /utrorf/ && $status{$k} eq 'keep')
    {   my $check = $k; $check =~ s/utrorf//;
		    if (exists($status{$check}))
				{   if ($status{$check} eq 'discard')
				    {   $status{$k} = 'discard';
						}
				}
				else
				{   $status{$k} = 'discard';
				}
		}
}
close(END);

open(END, ">../intermediate_2_prepare-network/3cv_filter-list_seq-n-dbs.txt");
foreach my $k (sort keys %status)
{   print END ($k."\t".$status{$k}."\n");
}
close(END);
