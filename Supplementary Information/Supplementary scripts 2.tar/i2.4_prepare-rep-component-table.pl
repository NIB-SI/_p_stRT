#!/usr/bin/perl -w
use strict;
my @lt = localtime();
my $date = ($lt[5]+1900)."-".sprintf("%02d", ($lt[4]+1))."-".sprintf("%02d", $lt[3]);

my %utrorfs = (); my %alts = ();
open(FILE, "../intermediate_2_prepare-network/3cv_evigene-header-network_unfiltered_weak-components_perWC-filtered.txt"); my @f = <FILE>; close(FILE); chomp(@f);
foreach my $line (@f)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    my @ids = split(/\|\|\|/, $s[3]);

				foreach my $id (@ids)
				{   if ($id =~ /utrorf/)
				    {   $utrorfs{$id} = 0;
						}
						else
						{   $alts{$id} = 0;
						}
				}
		}
}
foreach my $k (sort keys %utrorfs)
{   $k =~ s/utrorf//;
    if (exists($alts{$k}))
		{   delete ($alts{$k});
		    $utrorfs{$k} = 0;
		}
}

my %cdsLengths = ();
open(FILE, "../intermediate_1_preparing-files/3cvs_sequences_keep.txt"); my @f2 = <FILE>; close(FILE); chomp(@f2);
foreach my $line (@f2)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    $s[0] =~ s/>//;
				$cdsLengths{$s[0]} = length($s[2]);
		}
}

my %reps = ();
foreach my $line (@f)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    my @ids = split(/\|\|\|/, $s[3]);

				my $repID = '-'; my $repLn = 0;
				foreach my $id (@ids)
				{   if (exists($alts{$id}))
				    {   if ($cdsLengths{$id} > $repLn)
						    {   $repID = $id;
								    $repLn = $cdsLengths{$id};
								}
						}
				}
				$reps{$s[0]} = $repID;
		}
}

my $d = 1; my $p = 1; my $r = 1;
open(END, ">../intermediate_2_prepare-network/3cv_evigene-header-network_unfiltered_weak-components_perWC-filtered_with-rep.txt");
foreach my $line (@f)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    my @ids = split(/\|\|\|/, $s[3]);

				my $newWC = '';
				if ($s[1] eq 'D')   {   $newWC = 'stCuSTr-D_'.sprintf("%05d", $d); $d++;   }
				if ($s[1] eq 'P')   {   $newWC = 'stCuSTr-P_'.sprintf("%05d", $p); $p++;   }
				if ($s[1] eq 'R')   {   $newWC = 'stCuSTr-R_'.sprintf("%05d", $r); $r++;   }

				my $repID = $reps{$s[0]};
				foreach my $id (@ids)
				{   my $type = 'possible-alt';
				    if (exists($utrorfs{$id}))   {   $type = 'utrorf';   }
						if ($id eq $repID)           {   $type = 'representative';   }

						print END ($newWC."\t".$s[1]."\t".$s[2]."\t".$id."\t".$type."\n");
				}
		}
}
