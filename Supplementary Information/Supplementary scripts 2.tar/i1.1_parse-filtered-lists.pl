#!/usr/bin/perl -w
use strict;

### This script generates the lists of kept/discarded identifiers based on BLAST/IPR/BUSCO/etc information.

my %all = ();

open(FILE, "../input/Desiree_tr.cds.tsv");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    my @s = split(/\t/, $line);
    $all{$s[0]."\t".$s[1]."\t".$s[88]} = 0;
}
close(FILE);
open(FILE, "../input/PW363_tr.cds.tsv");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    my @s = split(/\t/, $line);
    $all{$s[0]."\t".$s[1]."\t".$s[88]} = 0;
}
close(FILE);
open(FILE, "../input/Rywal_tr.cds.tsv");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    my @s = split(/\t/, $line);
    $all{$s[0]."\t".$s[1]."\t".$s[88]} = 0;
}
close(FILE);

open(END, ">../intermediate_1_preparing-files/3cv_post-ev-filtered_keep.txt");
open(OTH, ">../intermediate_1_preparing-files/3cv_post-ev-filtered_discard.txt");
foreach my $k (sort keys %all)
{   my @s = split(/\t/, $k);
    if ($s[2] eq 'keep')
    {   print END ($k."\n");
    }
    elsif ($s[2] eq 'discard')
    {   print OTH ($k."\n");
    }
    else
    {   print $k."\n";
    }
}
close(END);
close(OTH);

# unlink("../input/Desiree_tr.cds.tsv");
# unlink("../input/PW363_tr.cds.tsv");
# unlink("../input/Rywal_tr.cds.tsv");
