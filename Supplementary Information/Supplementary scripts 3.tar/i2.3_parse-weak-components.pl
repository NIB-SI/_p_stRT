#!/usr/bin/perl -w
use strict;
my @lt = localtime();
my $date = ($lt[5]+1900)."-".sprintf("%02d", ($lt[4]+1))."-".sprintf("%02d", $lt[3]);

open(FILE, "../intermediate_2_prepare-network/pantr_evigene-header-network_unfiltered_weak-components.txt"); my @file = <FILE>; close(FILE); chomp(@file);
open(END, ">../intermediate_2_prepare-network/pantr_evigene-header-network_unfiltered_weak-components_perWC.txt");

my %comp = ();
my %compT = ();

foreach my $line (@file)
{   $line =~ s/\s+$//;
		unless ($line eq "" || $line =~ /Number\tLabel\t/)
		{   my @split = split(/\t/, $line);
		    my $id = "evigWC_".sprintf("%06d", $split[2]);

				if (exists($comp{$id}))
				{   $comp{$id} = $comp{$id}."|".$split[1];
				    if ($split[1] =~ /RY/)        {   $compT{$id} = $compT{$id}."|||R";   }
						elsif ($split[1] =~ /PW/)     {   $compT{$id} = $compT{$id}."|||P";   }
						elsif ($split[1] =~ /De/)     {   $compT{$id} = $compT{$id}."|||D";   }
						elsif ($split[1] =~ /PGSC/)   {   $compT{$id} = $compT{$id}."|||g";   }
						elsif ($split[1] =~ /Sotub/)  {   $compT{$id} = $compT{$id}."|||g";   }
				}
				else
				{   $comp{$id} = $split[1];
				    if ($split[1] =~ /RY/)        {   $compT{$id} = 'R';   }
						elsif ($split[1] =~ /PW/)     {   $compT{$id} = 'P';   }
						elsif ($split[1] =~ /De/)     {   $compT{$id} = 'D';   }
						elsif ($split[1] =~ /PGSC/)   {   $compT{$id} = "g";   }
						elsif ($split[1] =~ /Sotub/)  {   $compT{$id} = "g";   }
				}
		}
}
foreach my $k (sort keys %compT)
{   my @s = split(/\|\|\|/, $compT{$k});
    my %un = (); my $fin = '-';
		foreach my $s (@s)
		{   $un{$s} = 0;
		}
		foreach my $k (sort keys %un)
		{   if ($fin eq '-')   {   $fin = $k;   }
				else               {   $fin = $fin."|||".$k;   }
		}
		$compT{$k} = $fin;
}

foreach my $key (sort keys %comp)
{   my @s = split(/\|\|\|/, $comp{$key});
    print END ($key."\t".$compT{$key}."\t".@s."\t".$comp{$key}."\n");
}
close(END);
