#!/usr/bin/perl -w
use strict;

my %cdsLengths = ();
# too many differences; using the original sequence lengths and ignoring the different ones in the stPanTr Evigene run
# ../intermediate_1_preparing-files/pantr_sequences_keep.txt
open(FILE, "../input/3cvs_sequences_keep.txt"); my @f2a = <FILE>; close(FILE); chomp(@f2a);
foreach my $line (@f2a)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line); $s[0] =~ s/>//; $cdsLengths{$s[0]} = length($s[2]);
		}
}
open(FILE, "../input/phureja_sequences_keep.txt"); my @f2b = <FILE>; close(FILE); chomp(@f2b);
foreach my $line (@f2b)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line); $s[0] =~ s/>//; $cdsLengths{$s[0]} = length($s[2]);
		}
}

###

my %reps = (); my %alts = ();
open(FILE, "../intermediate_2_prepare-network/pantr_evigene-header-network_unfiltered_weak-components_perWC.txt"); my @f = <FILE>; close(FILE); chomp(@f);
foreach my $line (@f)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    my @ids = split(/\|/, $s[3]);

				my $repID = '-'; my $repLn = 0;
				foreach my $id (@ids)
				{   if ($cdsLengths{$id} > $repLn)
						{   $repID = $id;
						    $repLn = $cdsLengths{$id};
						}
				}
				$reps{$s[0]} = $repID;
		}
}

open(END, ">../intermediate_2_prepare-network/pantr_evigene-header-network_unfiltered_weak-components_perWC_with-rep.txt");
foreach my $line (@f)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);

				my $repID = $reps{$s[0]};
		    my @ids = split(/\|/, $s[3]);

				$s[0] =~ s/evigWC_/stPanTr_/;
				foreach my $id (@ids)
				{   my $type = 'alternative';
				    if ($id eq $repID)           {   $type = 'representative';   }

						print END ($s[0]."\t".$s[1]."\t".$s[2]."\t".$id."\t".$type."\n");
				}
		}
}
