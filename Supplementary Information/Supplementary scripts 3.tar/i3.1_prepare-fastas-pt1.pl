#!/usr/bin/perl -w
use strict;

my %seqAA = (); my %seqCD = (); my %seqTR = ();
open(FILE, "../input/3cvs_sequences_keep.txt"); my @f2a = <FILE>; close(FILE); chomp(@f2a);
foreach my $line (@f2a)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    $seqTR{$s[0]} = $s[1];
				$seqCD{$s[0]} = $s[2];
		    $seqAA{$s[0]} = $s[3];
		}
}
open(FILE, "../input/phureja_sequences_keep.txt"); my @f2b = <FILE>; close(FILE); chomp(@f2b);
foreach my $line (@f2b)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    $seqTR{">".$s[0]} = $s[1];
				$seqCD{">".$s[0]} = $s[2];
		    $seqAA{">".$s[0]} = $s[3];
		}
}

open(FILE, "../intermediate_2_prepare-network/pantr_evigene-header-network_unfiltered_weak-components_perWC-filtered_with-rep.txt"); my @f = <FILE>; close(FILE); chomp(@f);

open(REPA, ">../output/stCuSTr_aa_representatives.fasta");
open(REPC, ">../output/stCuSTr_cds_representatives.fasta");
open(REPT, ">../output/stCuSTr_tr_representatives.fasta");

open(ALTA, ">../output/stCuSTr_aa_alternatives.fasta");
open(ALTC, ">../output/stCuSTr_cds_alternatives.fasta");
open(ALTT, ">../output/stCuSTr_tr_alternatives.fasta");

foreach my $line (@f)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    if ($s[4] eq 'representative')
				{   print REPA (">$s[3]\n".$seqAA{'>'.$s[3]}."\n");
				    print REPC (">$s[3]\n".$seqCD{'>'.$s[3]}."\n");
						print REPT (">$s[3]\n".$seqTR{'>'.$s[3]}."\n");
				}
				elsif ($s[4] eq 'alternative')
				{   print ALTA (">$s[3]\n".$seqAA{'>'.$s[3]}."\n");
				    print ALTC (">$s[3]\n".$seqCD{'>'.$s[3]}."\n");
						print ALTT (">$s[3]\n".$seqTR{'>'.$s[3]}."\n");
				}
				else
				{   print $line."\n";
				}
		}
}
