#!/usr/bin/perl -w
use strict;

my %all = (); my %seqTR = (); my %seqAA = (); my %seqCD = ();
### This script prepares keep/discard lists based on existence of tr/cds/aa sequences from part 1 of the script.
### In the case of utrorfs, it looks for it's parent in the TR table: if it finds it, then it copies it over, if not, it places into the discard file.

open(FILE, "../intermediate_1_preparing-files/pantr_tr.txt");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    unless ($line eq "" || $line =~ /utrorf/) # 15 utrorf sequences, all from Sotub, did not want to define new ones
    {   my @s = split(/\t/, $line); $all{$s[0]} = 0; $seqTR{$s[0]} = $s[1];
    }
}
close(FILE);

open(FILE, "../intermediate_1_preparing-files/pantr_aa.txt");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    unless ($line eq "" || $line =~ /utrorf/) # 15 utrorf sequences, all from Sotub, did not want to define new ones
    {   my @s = split(/\t/, $line); $all{$s[0]} = 0; $seqAA{$s[0]} = $s[1];
    }
}
close(FILE);

open(FILE, "../intermediate_1_preparing-files/pantr_cds.txt");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    unless ($line eq "" || $line =~ /utrorf/) # 15 utrorf sequences, all from Sotub, did not want to define new ones
    {   my @s = split(/\t/, $line); $all{$s[0]} = 0; $seqCD{$s[0]} = $s[1];
    }
}
close(FILE);

foreach my $k (sort keys %all)
{   unless (exists($seqTR{$k}))   {   $seqTR{$k} = '-';   }
    unless (exists($seqAA{$k}))   {   $seqAA{$k} = '-';   }
    unless (exists($seqCD{$k}))   {   $seqCD{$k} = '-';   }
}

my %phureja = ();
open(FILE, "../input/phureja_sequences_keep.txt");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    unless ($line eq "")
    {   my @s = split(/\t/, $line);
        $phureja{">".$s[0]} = ">".$line;
    }
}
close(FILE);


open(END, ">../intermediate_1_preparing-files/pantr_sequences_keep.txt");
open(OTH, ">../intermediate_1_preparing-files/pantr_sequences_discard.txt");
foreach my $k (sort keys %all)
{   if ($seqTR{$k} eq '-' || $seqCD{$k} eq '-' || $seqAA{$k} eq '-')
    {   if (exists($phureja{$k}))
        {   print END ($phureja{$k}."\n");
        }
        else
        {   print OTH ($k."\t".$seqTR{$k}."\t".$seqCD{$k}."\t".$seqAA{$k}."\n");
        }
    }
    else
    {   print END ($k."\t".$seqTR{$k}."\t".$seqCD{$k}."\t".$seqAA{$k}."\n");
    }
}
close(END);
close(OTH);

# unlink("../intermediate_1_preparing-files/3cvs_aa.txt");
# unlink("../intermediate_1_preparing-files/3cvs_cds.txt");
# unlink("../intermediate_1_preparing-files/3cvs_tr.txt");
