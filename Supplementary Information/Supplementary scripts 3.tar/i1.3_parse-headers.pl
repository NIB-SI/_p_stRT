#!/usr/bin/perl -w
use strict;

### This script parses the Evigene fasta headers into binary connections between nodes mentioned within the header.
### It works on headers from the okay and okalt sets, not if you include headers from the dropped also!

open(FILE, "../intermediate_1_preparing-files/pantr_evigene-headers.txt"); my @file = <FILE>; close(FILE); chomp(@file);
open(END, ">../intermediate_1_preparing-files/pantr_evigene-headers_table-format.txt");

my %counts = ();

foreach my $line (@file)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @split = split(/\t/, $line); $split[0] =~ s/>//;
				print END ($split[0]."\t".$split[0]."\n"); # self-connection

				my @sec = split(/;/, $split[1]);
				if (@sec == 1 && $sec[0] =~ /match:/) # perfectdup / perfectfrag
				{   my @thi = split(/match:/, $sec[0]);
				    print END ($split[0]."\t".$thi[1]."\n");
				}
				elsif (@sec == 1) # these were without a fasta header, IGNORED
				{}
				elsif (@sec == 2 && $sec[0] =~ /match/)
				{   my @thi = split(/match:/, $sec[0]);
				    my @fou = split(/,pct:/, $thi[1]);
						my @fif = split(/\//, $fou[1]);
						print END ($split[0]."\t".$fou[0]."\n");
						if (exists($fif[3]))
						{   print END ($split[0]."\t".$fif[3]."\n");
						    print END ($fou[0]."\t".$fif[3]."\n");
					  }
				}
				elsif (@sec == 2) # these were without any match (main,okay / noclass,drop / noclass,okay, noclass2,okay), IGNORED
				{}
				elsif (@sec == 5) # these did not contain any match, IGNORED
				{}
				elsif (@sec == 6 && $sec[5] =~ /match/)
			  {   my @thi = split(/match:/, $sec[5]);
						my @fou = split(/,pct:/, $thi[1]);
						if (@fou == 2)
						{   my @fif = split(/\//, $fou[1]);
						    print END ($split[0]."\t".$fou[0]."\n");
								if (exists($fif[3]))
								{   print END ($split[0]."\t".$fif[3]."\n");
										print END ($fou[0]."\t".$fif[3]."\n");
								}
					  }
				}
				elsif (@sec == 6) # these were without any match (main,okay / noclass,drop / noclass,okay, noclass2,okay), IGNORED
				{}
		}
}

foreach my $k (sort keys %counts)
{   print END ($k."\n");
}
close(END);

my %uniqConn = ();
open(FILE, "../intermediate_1_preparing-files/pantr_evigene-headers_table-format.txt"); my @file2 = <FILE>; close(FILE); chomp(@file2);
open(END, ">../intermediate_1_preparing-files/pantr_evigene-headers_table-format.txt");
foreach my $line (@file2)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   $uniqConn{$line} = 0;
		}
}
foreach my $un (sort keys %uniqConn)
{   unless ($un =~ /utrorf/)
    {   print END ($un."\n");
	  }
}
close(END);
