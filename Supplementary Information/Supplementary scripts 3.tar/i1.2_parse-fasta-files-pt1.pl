#!/usr/bin/perl -w
use strict;

my %headers = ();
### This script takes the sequence files returned from evigene (see output of Evigene folder), extracts the headers and linearizes the sequences in files.

open(FILE, "../input/pantr_aa.fasta");
open(LIN, ">../intermediate_1_preparing-files/pantr_aa.txt");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    if (substr($line,0,1) eq '>')
    {   my @s = split(/ /, $line); print LIN ("\n".$s[0]."\t"); # for the fasta file
        $line =~ s/$s[0] //; $headers{$s[0]."\t".$line} = 0;    # for the header file
    }
    else
    {   print LIN ($line);
    }
}
close(FILE); close(LIN);

open(FILE, "../input/pantr_cds.fasta");
open(LIN, ">../intermediate_1_preparing-files/pantr_cds.txt");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    if (substr($line,0,1) eq '>')
    {   my @s = split(/ /, $line); print LIN ("\n".$s[0]."\t"); # for the fasta file
        $line =~ s/$s[0] //; $headers{$s[0]."\t".$line} = 0;    # for the header file
    }
    else
    {   print LIN ($line);
    }
}
close(FILE); close(LIN);

open(FILE, "../input/pantr_tr.fasta");
open(LIN, ">../intermediate_1_preparing-files/pantr_tr.txt");
while (defined(my $line = <FILE>))
{   $line =~ s/\s+$//;
    if (substr($line,0,1) eq '>')
    {   my @s = split(/ /, $line); print LIN ("\n".$s[0]."\t"); # for the fasta file
        $line =~ s/$s[0] //; $headers{$s[0]."\t".$line} = 0;    # for the header file
    }
    else
    {   print LIN ($line);
    }
}
close(FILE); close(LIN);

open(END, ">../intermediate_1_preparing-files/pantr_evigene-headers.txt");
foreach my $k (sort keys %headers)
{   while ($k =~ /  /)   {   $k =~ s/  / /g;   }
    while ($k =~ /; /)   {   $k =~ s/; /;/g;   }
    print END ($k."\n");
}
close(END);

# unlink("../input/3cvs_aa.fasta");
# unlink("../input/3cvs_cds.fasta");
# unlink("../input/3cvs_tr.fasta");
