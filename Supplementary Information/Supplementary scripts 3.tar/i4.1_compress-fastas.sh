#!/bin/sh
# zagor

# see https://www.cyberciti.biz/howto/question/general/compress-file-unix-linux-cheat-sheet.php in the case you need to uncompress some data

for file in ../input/*
do
    gzip $file
done

for file in ../output/*
do
    gzip $file
done
